package ch.heigvd.dai.protocol;

public class CommandException extends Exception {
    public CommandException(String message) {
        super(message);
    }
}
